'use strict';  

// NOTE: Don't change the port number
const PORT = 3000;

// The variable stocks has the same value as the variable stocks in the file `stocks.js`
const stocks = require('./stocks.js').stocks;
const fs = require("fs")

const express = require("express");
const app = express();

app.use(express.urlencoded({
    extended: true
}));

// Code begins here
let welcome = `Welcome to Katie's first homepage!`
console.log(welcome)

app.get("/", (req, res) => {
    fs.readFile("views/index.html", "utf8", (err, data) => {
        if (err){
            res.statusCode = 500
            res.send("error reading file")
            return
        }
        res.send(data)
    })
});

app.get("/Stock_Listing", (req, res) => {
    fs.readFile("views/Listing.html", "utf8", (err, data) => {
        if (err){
            res.statusCode = 500
            res.send("error reading file")
            return
        }
        res.send(data)
    })
});


app.get("/Stock_Search", (req, res) => {
    fs.readFile("views/Search.html", "utf8", (err, data) => {
        if (err){
            res.statusCode = 500
            res.send("error reading file")
            return
        }
        res.send(data)
    })
});

app.use(express.urlencoded({
    extended: true
}));

app.post("/select_stock", (req, res) => {
    let quantity = parseInt(req.body.quantity)
    let stock = req.body.stock
    let price = stocks.filter(s => s.symbol == stock)[0].price 
    res.send(`You purchased ${quantity} stocks of ${stock} at the cost of $ ${(quantity * price).toFixed(2)}`);
});

function findStockByPrice(option){
    let high = 0
    let low = 2147483647        //highest 32 bit value
    let x = 0
    let y = 0

    for (var i = 0; i < stocks.length; i++){ 
        console.log(stocks[i].price)
        if (stocks[i].price > high){
            high = stocks[i].price
            x = i
        }
        if (stocks[i].price < low){
            low = stocks[i].price
            y = i
        }
    }
    if (option === 1){
        return stocks[x]
    }
    else {
        return stocks[y]
    }
};

app.post("/search", (req, res) => {
   var value=req.body.val;

    if (value === "highest"){
        let high = findStockByPrice(1)
        let s = "The highest priced stock is" +JSON.stringify(high)
        res.send(s);
    }
    else {
        let low = findStockByPrice(0)
        let s = "The lowest priced stock is" +JSON.stringify(low)
        res.send(s);
           
    }
});

app.get("/stocks", (req,res) => {
    res.send(JSON.stringify(stocks))
})
app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}...`);
});