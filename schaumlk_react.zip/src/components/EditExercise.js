import React from 'react';

function EditExercise({ exercise, updateExercise }) {
    const updateValue = (name, value) => {
        exercise[name] = value
        updateExercise(exercise)
    }
    return (
        <table id="exercises">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Reps</th>
                    <th>Weight</th>
                    <th>Unit</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <td><input type="text" value={exercise.name} onChange={e => updateValue("name", e.target.value)}/></td>
                <td><input type="text" value={exercise.reps} onChange={e => updateValue("reps", e.target.value)}/></td>
                <td><input type="text" value={exercise.weight} onChange={e => updateValue("weight", e.target.value)}/></td>
                <td><input type="text" value={exercise.unit} onChange={e => updateValue("unit", e.target.value)}/></td>
                <td><input type="text" value={exercise.date} onChange={e => updateValue("date", e.target.value)}/></td>
        </tr>
            </tbody>
        </table>
    );
}

export default EditExercise;