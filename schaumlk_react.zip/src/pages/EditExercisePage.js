import React, { useState } from 'react';
import { useHistory } from "react-router-dom";

export const EditExercisePage = ({exercise}) => {

    const convertDate = date => `20${date.substr(6,2)}-${date.substr(0,2)}-${date.substr(3,2)}`
    const deconvertDate = date => `${date.substr(5,2)}-${date.substr(8,2)}-${date.substr(2,2)}`
    //yyyy-mm-dd
    //0123456789
    const [name, setName] = useState(exercise.name);
    const [reps, setReps] = useState(exercise.reps);
    const [weight, setWeight] = useState(exercise.weight);
    const [unit, setUnit] = useState(exercise.unit);
    const [date, setDate] = useState(convertDate(exercise.date))

    const history = useHistory();

    const updateExercise = async () => {
        const newExercise = { 
            name, 
            reps: parseInt(reps), 
            weight: parseInt(weight), 
            unit, 
            date: deconvertDate(date) };
        const response = await fetch(`/exercises/${exercise._id}`, {
            method: 'PUT',
            body: JSON.stringify(newExercise),
            headers: {
                'Content-Type': 'application/json',
            },
        });
        if (response.status === 201) {
            alert("Successfully updated the exercise");
        } else {
            alert(`Failed to update exercise, status code = ${response.status}`);
        }
        history.push("/");
    };

    return (
        <div>
            <h1>Edit Exercise</h1>
            <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Reps</th>
                    <th>Weight</th>
                    <th>Unit</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <td><input
                type="text"
                value={name}
                placeholder="Enter the name of the exercise"
                onChange={e => setName(e.target.value)} /></td>
            <td><input
                type="number"
                value={reps}
                placeholder="Enter number of reps here"
                onChange={e => setReps(e.target.value)} /></td>
            <td><input
                type="number"
                placeholder="Enter weight here"
                value={weight}
                onChange={e => setWeight(e.target.value)} /></td>
             <td><select
                type="text"
                placeholder="Enter unit here"
                value={unit}
                onChange={e => setUnit(e.target.value)} >
                    <option value="lbs">lbs</option>
                    <option value="kg">kg</option>
                    </select></td>
             <td><input
                type="date"
                placeholder="Enter date here"
                value={date}
                onChange={e => setDate(e.target.value)} /></td>
            </tr>
            </tbody>
            </table>
            <button
                onClick={updateExercise}
            >Update</button>
        </div>
    );
}

export default EditExercisePage;