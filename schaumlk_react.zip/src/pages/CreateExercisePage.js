import React, { useState } from 'react';
import { useHistory } from "react-router-dom";

export const CreateExercisePage = () => {
    const deconvertDate = date => `${date.substr(5,2)}-${date.substr(8,2)}-${date.substr(2,2)}`
    const [name, setName] = useState('');
    const [reps, setReps] = useState(0);
    const [weight, setWeight] = useState(0);
    const [unit, setUnit] = useState('lbs');
    const [date, setDate] = useState('')

    const history = useHistory();

    const addExercise = async () => {
        const newExercise = { 
            name, 
            reps: parseInt(reps), 
            weight: parseInt(weight), 
            unit, 
            date: deconvertDate(date) };
        const response = await fetch('/exercises', {
            method: 'POST',
            body: JSON.stringify(newExercise),
            headers: {
                'Content-Type': 'application/json',
            },
        });
        if (response.status === 201) {
            alert("Successfully added the exercise");
        } else {
            alert(`Failed to add exercise, status code = ${response.status}`);
        }
        history.push("/");
    };

    return (
        <div>
            <h1>Add Exercise</h1>
            <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Reps</th>
                    <th>Weight</th>
                    <th>Unit</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <td><input
                type="text"
                value={name}
                placeholder="Enter the name of the exercise"
                onChange={e => setName(e.target.value)} /></td>
            <td><input
                type="number"
                value={reps}
                placeholder="Enter number of reps here"
                onChange={e => setReps(e.target.value)} /></td>
            <td><input
                type="number"
                placeholder="Enter weight here"
                value={weight}
                onChange={e => setWeight(e.target.value)} /></td>
             <td><select
                type="text"
                placeholder="Enter unit here"
                value={unit}
                onChange={e => setUnit(e.target.value)} >
                    <option value="lbs">lbs</option>
                    <option value="kg">kg</option>
                    </select></td>
             <td><input
                type="date"
                placeholder="Enter date here"
                value={date}
                onChange={e => setDate(e.target.value)} /></td>
            </tr>
            </tbody>
            </table>
            <button
                onClick={addExercise}
            >Add</button>
        </div>
    );
}

export default CreateExercisePage;